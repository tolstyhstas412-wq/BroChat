# BroChat — Android messenger starter

Это исходный проект Android-приложения BroChat на Kotlin + Jetpack Compose + Firebase.
Включены регистрация/вход, список зарегистрированных пользователей, поиск по пользователям,
личные чаты и синхронизация текстовых сообщений в реальном времени через Firestore.

## Важно
Проект не является уже собранным APK. Для настоящей работы нужен ваш Firebase-проект,
его конфигурация `google-services.json`, правила безопасности Firestore и сборка на Android SDK.
Без Firebase-конфигурации приложение не сможет регистрировать пользователей и обмениваться сообщениями.

## Подключение Firebase
1. Откройте https://console.firebase.google.com/ и создайте проект BroChat.
2. Добавьте Android-приложение с package name `com.brochat.app`.
3. Скачайте `google-services.json` и положите его в папку `app/`. Добавьте плагин Google Services в `app/build.gradle.kts`, если будете подключать Firebase SDK-конфигурацию.
4. В Firebase Authentication включите Email/Password.
5. Создайте Cloud Firestore database.
6. В Android Studio откройте папку проекта и дождитесь Gradle Sync.

## Начальные правила Firestore
Для быстрого теста можно временно использовать правила ниже, но НЕ публикуйте приложение с ними.
Настройте production rules, ограничивающие доступ только участникам чата и владельцу профиля.

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function signedIn() { return request.auth != null; }

    match /users/{userId} {
      allow read: if signedIn();
      allow create, update: if signedIn() && request.auth.uid == userId;
    }

    match /chats/{chatId} {
      allow read, create, update: if signedIn()
        && request.auth.uid in resource.data.members;
      allow create: if signedIn()
        && request.auth.uid in request.resource.data.members;

      match /messages/{messageId} {
        allow read: if signedIn()
          && request.auth.uid in get(/databases/$(database)/documents/chats/$(chatId)).data.members;
        allow create: if signedIn()
          && request.resource.data.senderId == request.auth.uid
          && request.auth.uid in get(/databases/$(database)/documents/chats/$(chatId)).data.members;
      }
    }
  }
}
```

## Сборка APK
В Android Studio:
- Build → Build Bundle(s) / APK(s) → Build APK(s)
- APK обычно появится в `app/build/outputs/apk/debug/app-debug.apk`.

Или из терминала в корне проекта:
```bash
./gradlew assembleDebug
```

Для публикации нужен подписанный release APK/AAB: Build → Generate Signed Bundle / APK.

## Что пока не реализовано
Групповые чаты, вложения/фото/видео, голосовые сообщения, push-уведомления,
редактирование/удаление сообщений, блокировки, жалобы, шифрование end-to-end,
модерация и полноценная система статусов. Это следующий этап разработки.


## Автоматическая сборка на GitHub
В корне проекта есть workflow `.github/workflows/build.yml`. Он собирает debug APK и публикует его как Artifact в Actions. Для текущей сборки Firebase-конфигурация не обязательна для компиляции, но без неё онлайн-функции не будут работать.
