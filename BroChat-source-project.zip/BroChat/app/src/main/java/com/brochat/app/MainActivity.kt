package com.brochat.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF17212B)
private val Panel = Color(0xFF202B36)
private val Blue = Color(0xFF2AABEE)
private val Muted = Color(0xFF8B9AA8)
private val White = Color(0xFFEAF2F8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BroChatApp() }
    }
}

data class ChatUser(val uid: String, val name: String, val email: String)
data class ChatMessage(val id: String, val senderId: String, val text: String, val time: Long)

@Composable
fun BroChatApp() {
    val auth = remember { FirebaseAuth.getInstance() }
    var currentUser by remember { mutableStateOf(auth.currentUser) }
    var selected by remember { mutableStateOf<ChatUser?>(null) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Blue, background = Navy, surface = Panel,
        onBackground = White, onSurface = White
    )) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            if (currentUser == null) {
                AuthScreen(
                    onAuth = { email, password, name, register ->
                        val task = if (register) auth.createUserWithEmailAndPassword(email, password)
                                   else auth.signInWithEmailAndPassword(email, password)
                        task.addOnSuccessListener {
                            val user = auth.currentUser
                            if (user != null) {
                                if (register) FirebaseFirestore.getInstance()
                                    .collection("users").document(user.uid)
                                    .set(mapOf("uid" to user.uid, "name" to name, "email" to email))
                                currentUser = user
                            }
                        }
                    }
                )
            } else if (selected == null) {
                ChatsScreen(
                    uid = currentUser!!.uid,
                    onSelect = { selected = it },
                    onLogout = { auth.signOut(); currentUser = null }
                )
            } else {
                DirectChatScreen(
                    me = currentUser!!.uid,
                    other = selected!!,
                    onBack = { selected = null }
                )
            }
        }
    }
}

@Composable
fun AuthScreen(onAuth: (String, String, String, Boolean) -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var register by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("✈", color = Blue, fontSize = 48.sp)
        Text("BroChat", color = White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Text("Общайся без границ", color = Muted, modifier = Modifier.padding(bottom = 28.dp))
        if (register) {
            OutlinedTextField(name, { name = it }, label = { Text("Имя") }, singleLine = true)
            Spacer(Modifier.height(10.dp))
        }
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(password, { password = it }, label = { Text("Пароль") }, singleLine = true)
        if (error.isNotBlank()) Text(error, color = Color.Red)
        Spacer(Modifier.height(18.dp))
        Button(
            onClick = {
                if (email.isBlank() || password.length < 6 || (register && name.isBlank())) {
                    error = "Проверь email, имя и пароль (минимум 6 символов)"
                } else {
                    error = ""
                    onAuth(email.trim(), password, name.trim(), register)
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (register) "Создать аккаунт" else "Войти") }
        TextButton(onClick = { register = !register; error = "" }) {
            Text(if (register) "Уже есть аккаунт? Войти" else "Создать новый аккаунт")
        }
        Text("Для работы подключи Firebase (инструкция в README)", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun ChatsScreen(uid: String, onSelect: (ChatUser) -> Unit, onLogout: () -> Unit) {
    var users by remember { mutableStateOf<List<ChatUser>>(emptyList()) }
    var search by remember { mutableStateOf("") }

    DisposableEffect(uid) {
        val reg = FirebaseFirestore.getInstance().collection("users")
            .addSnapshotListener { snap, _ ->
                users = snap?.documents?.mapNotNull { d ->
                    val id = d.getString("uid") ?: d.id
                    val name = d.getString("name") ?: d.getString("email") ?: "Пользователь"
                    val email = d.getString("email") ?: ""
                    if (id == uid) null else ChatUser(id, name, email)
                } ?: emptyList()
            }
        onDispose { reg.remove() }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().background(Panel).padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("BroChat", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("Сообщения", color = Muted, fontSize = 12.sp)
            }
            TextButton(onClick = onLogout) { Text("Выйти") }
        }
        OutlinedTextField(
            value = search, onValueChange = { search = it },
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            placeholder = { Text("Поиск людей") }, singleLine = true
        )
        LazyColumn {
            items(users.filter { it.name.contains(search, true) || it.email.contains(search, true) }) { user ->
                Row(
                    Modifier.fillMaxWidth().clickable { onSelect(user) }.padding(horizontal = 16.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(48.dp).background(Blue, CircleShape), contentAlignment = Alignment.Center) {
                        Text(user.name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Column(Modifier.padding(start = 13.dp)) {
                        Text(user.name, color = White, fontWeight = FontWeight.SemiBold)
                        Text(user.email, color = Muted, fontSize = 12.sp)
                    }
                }
                HorizontalDivider(color = Panel)
            }
        }
    }
}

@Composable
fun DirectChatScreen(me: String, other: ChatUser, onBack: () -> Unit) {
    val db = remember { FirebaseFirestore.getInstance() }
    val chatId = remember(me, other.uid) { listOf(me, other.uid).sorted().joinToString("_") }
    var messages by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
    var draft by remember { mutableStateOf("") }

    DisposableEffect(chatId) {
        val reg = db.collection("chats").document(chatId).collection("messages")
            .orderBy("time", Query.Direction.ASCENDING)
            .limitToLast(200)
            .addSnapshotListener { snap, _ ->
                messages = snap?.documents?.mapNotNull { d ->
                    val sender = d.getString("senderId") ?: return@mapNotNull null
                    val text = d.getString("text") ?: return@mapNotNull null
                    ChatMessage(d.id, sender, text, d.getLong("time") ?: 0L)
                } ?: emptyList()
            }
        onDispose { reg.remove() }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().background(Panel).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Назад", tint = White) }
            Column {
                Text(other.name, color = White, fontWeight = FontWeight.Bold)
                Text("личный чат", color = Muted, fontSize = 11.sp)
            }
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth().padding(12.dp),
            reverseLayout = false
        ) {
            items(messages) { msg ->
                val mine = msg.senderId == me
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                    Column(
                        Modifier.padding(vertical = 4.dp)
                            .widthIn(max = 300.dp)
                            .background(if (mine) Color(0xFF2B5278) else Panel, RoundedCornerShape(15.dp))
                            .padding(horizontal = 13.dp, vertical = 9.dp)
                    ) {
                        Text(msg.text, color = White)
                        Text(
                            if (msg.time > 0) SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(msg.time)) else "",
                            color = Color(0xFFB7C8D8), fontSize = 10.sp,
                            modifier = Modifier.align(Alignment.End).padding(top = 4.dp)
                        )
                    }
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().background(Panel).padding(9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = draft, onValueChange = { draft = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Сообщение…") },
                maxLines = 4
            )
            IconButton(onClick = {
                val text = draft.trim()
                if (text.isNotEmpty()) {
                    val payload = mapOf("senderId" to me, "text" to text, "time" to System.currentTimeMillis())
                    db.collection("chats").document(chatId).collection("messages").add(payload)
                    db.collection("chats").document(chatId).set(
                        mapOf("members" to listOf(me, other.uid), "lastMessage" to text, "updatedAt" to System.currentTimeMillis())
                    )
                    draft = ""
                }
            }) { Icon(Icons.Default.Send, contentDescription = "Отправить", tint = Blue) }
        }
    }
}
